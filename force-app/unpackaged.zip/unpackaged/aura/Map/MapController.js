({
    jsLoaded: function(component) {
        component.set("v.jsLoaded", true);
    }  
})